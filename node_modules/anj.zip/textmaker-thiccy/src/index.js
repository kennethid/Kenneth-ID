exports.textpro = require("../lib/textmaker/textpro");
exports.photooxy = require("../lib/textmaker/photooxy");
