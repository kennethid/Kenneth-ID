// Run `node example.js` in terminal
const angkaTerbilang = require('./'); // require the `index.js` file from the same directory.
console.log(angkaTerbilang('1192391239213'))